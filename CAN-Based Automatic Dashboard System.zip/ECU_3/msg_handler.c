#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include "string.h"
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "msg_handler.h"


void handle_speed_data(uint8_t *data, uint8_t len) {
    
    clcd_print(data, LINE1(2)); //2 3 
}   

void handle_gear_data(uint8_t *data, uint8_t len) {
   
    clcd_print(data, LINE1(7)); 
}

//---------------- RPM ----------------//
void handle_rpm_data(uint8_t *data, uint8_t len) {
   
   clcd_print(data, LINE1(11));  // Display after "RPM:"
}

//---------------- ENGINE TEMPERATURE ----------------//
void handle_engine_temp_data(uint8_t *data, uint8_t len) {
   
    clcd_print(data, LINE2(3)); // Display after "TEMP:"
}

void handle_indicator_data(uint8_t *data, uint8_t len) {
    // Optional position
     clcd_print(data, LINE2(9)); 
}

//---------------- CAN DATA PROCESSING ----------------//
void process_canbus_data(void)
{
    uint16_t msg_id;
    uint8_t data[8];
    uint8_t len;
    
    can_receive(&msg_id, data, &len);
   

       switch (msg_id)     
       {
           case SPEED_MSG_ID:
                handle_speed_data(data, len);
               break;
           case GEAR_MSG_ID:
                handle_gear_data(data, len);
                break;
            case RPM_MSG_ID:
                handle_rpm_data(data, len);
                break;
            case ENG_TEMP_MSG_ID:
                handle_engine_temp_data(data, len);
                break;
                
            case INDICATOR_MSG_ID:
                handle_indicator_data(data, len);
                break;
        }
       
}