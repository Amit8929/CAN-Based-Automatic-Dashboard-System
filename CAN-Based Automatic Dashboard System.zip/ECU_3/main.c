#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "msg_handler.h"
#include "timer0.h"

#define _XTAL_FREQ 20000000

// Initialization of peripherals
static void init_config(void) {
    init_clcd();       // Initialize Character LCD
    init_can();        // Initialize CAN bus
    init_timer0();     // Timer0 if required

    // Enable Peripheral & Global interrupts
    PEIE = 1;
    GIE  = 1;
}

void main(void) {
    // Initialize peripherals and LCD labels
    init_config();
    //CLEAR_DISP_SCREEN;
    clcd_print("S:", LINE1(0));
    clcd_print("G:",  LINE1(5));
    clcd_print("R:",   LINE1(10));
    clcd_print("T:",  LINE2(0));
    clcd_print("wdtfasI:",  LINE2(7));

   
    while (1)
    {
        
        
        process_canbus_data();
    }
}