#include<xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_d.h"
#include "uart.h"
#include <string.h>
#define _XTAL_FREQ 20000000
static const char *indicator[4]={"LE","RI","BO","OF"};
void my_itoa(unsigned int speed ,unsigned char res[])
{
    int i=0,j=0;
    unsigned char temp[10];

    if(speed==0)
    {
        res[0]='0';
        res[1]='\0';
        return ;
    }

    while(speed > 0)
    {
        temp[i++]=(speed %10)+'0';
        speed=speed/10;
    }

    for(j=0;j<i;j++)
    {
        res[j]=temp[i-j-1];
    }

    res[i]='\0';
}
void init_config()
{
    init_adc();
    init_can();
    init_digital_keypad();
    init_uart();
}
int main()
{   
    init_config();
    unsigned int rpm;
    unsigned int temp;
    unsigned char indi;
    unsigned char str[10];
    unsigned char str1[10];
    
    while(1)
    {
        rpm=get_rpm();
        my_itoa(rpm,str);
        
        temp=get_engine_temp();
         my_itoa(temp,str1);
       
       indi= process_indicator();
       
    puts("RPM: ");
    puts(str);
    can_transmit(RPM_MSG_ID,str, 4);
    __delay_ms(90);

    puts("   ENG:TEMP: ");
    puts(str1);
    can_transmit(ENG_TEMP_MSG_ID ,str1,2);
    __delay_ms(90);
    
    puts("  INDICATOR:   ");
    puts(indicator[indi]);   
    can_transmit(INDICATOR_MSG_ID ,indicator[indi], 2);
    puts("\r\n");
   __delay_ms(90);
    
        
    }
}
