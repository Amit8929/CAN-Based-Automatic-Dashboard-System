#include<xc.h>
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_d.h"
#include "uart.h"

uint16_t get_rpm()
{
    //Implement the rpm functio
        unsigned int new_val;
        new_val= (read_adc(CHANNEL4)*5999)/1023;
        new_val=new_val*100;
        return new_val;  
}

uint16_t get_engine_temp()
{
    //Implement the engine temperature function
      unsigned int adc_val;
    int  voltage, temperature;

    adc_val = (read_adc(CHANNEL6)*5.0)/1023;

     // Convert to voltage
    temperature = voltage; 
    return temperature;
}

IndicatorStatus process_indicator()
{
    //Implement the indicator function
     static unsigned char indx=0;
        unsigned int key=read_digital_keypad(STATE_CHANGE);
        if(key==SWITCH1)
        {
            indx=(indx+1)%4;
        }
        else if(key==SWITCH2)
        {
            if(indx<=0) indx=0;
            else indx--;
        }
        return indx;
}